import org.springframework.context.support.GenericXmlApplicationContext;

import dao.GoodDao;

public class Main {

	public static void main(String[] args) throws Exception {
		try {
			GenericXmlApplicationContext context = new GenericXmlApplicationContext("applicationContext.xml");
			GoodDao dao = context.getBean(GoodDao.class);
			System.out.println(dao.allgood());
			context.close();
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

}

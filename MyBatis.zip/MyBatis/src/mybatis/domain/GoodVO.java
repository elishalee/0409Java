package mybatis.domain;

import java.util.Date;

import lombok.Data;

@Data
public class GoodVO {
	private int code;
	private String name;
	private Date regdate;
	
	public GoodVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GoodVO(int code, String name, Date regdate) {
		super();
		this.code = code;
		this.name = name;
		this.regdate = regdate;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	@Override
	public String toString() {
		return "GoodVO [code=" + code + ", name=" + name + "]";
	}
	
	
}

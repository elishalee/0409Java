package mybatis.domain;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

// bean을 자동 생성할 수 있도록 해주는 어노테이션 - IoC(제어의 역전)
// Component, Controller, Service, Repository
@Repository
public class GoodDAO {
	// 데이터베이스 연동 프레임워크의 변수
	// 동일한 자료형의 bean이 있으면 자동으로 주입해주는 어노테이션
	@Autowired
	private SqlSession sqlSession;
	
	// 테이블의 전체 데이터를 가져오는 메소드
	// 파라미터 없이 전체 데이터를 가져오는 sql을 호출
	public List<Good> allGood() {
		return sqlSession.selectList("good.allgood");
	}
	
	// code를 입력받아서 데이터 1개를 찾아오는 매소드
	public Good getGood(int code) {
		return sqlSession.selectOne("good.getgood", code);
	}
	
	// 데이터 삽입 메소드
	public int insertGood(Good good) {
		return sqlSession.insert("good.insertgood", good);
	}
	
	// 데이터 수정 메소드
	public int updateGood(Good good) {
		return sqlSession.update("good.updategood", good);
	}
	
	// 데이터 삭제 메소드
	// 삭제는 기본키가 필요해서 기본키 기재 필요!
	public int deleteGood(int code) {
		return sqlSession.delete("good.deletegood", code);
	}
}

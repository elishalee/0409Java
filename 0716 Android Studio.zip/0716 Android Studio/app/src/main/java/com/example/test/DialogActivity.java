package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DialogActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog);

        Button digShow = (Button)findViewById(R.id.dlgshow);
        digShow.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                // 대화상자 생성
                Dialog dig = new Dialog(DialogActivity.this);
                TextView txtView =
                        new TextView(
                                DialogActivity.this);

                txtView.setText("대화상자 출력");
                // 모양 설정
                dig.setContentView(txtView);
                dig.setTitle("대화상자");
                // 출력
                dig.show();
            }
        });

        Button alertdialog = (Button)findViewById(R.id.alertdlgshow);
        alertdialog.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                AlertDialog.Builder dlg = new AlertDialog.Builder(DialogActivity.this);
                // 메소드 체이닝(메소드를 연쇄적으로 부름)
                dlg.setTitle("제목")
                        .setCancelable(false)
                        .setPositiveButton("확인", null)
                        .setMessage("내용")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

            }
        });



    }
}